package dev.flutterclutter.flutter_animated_splash_screen;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
