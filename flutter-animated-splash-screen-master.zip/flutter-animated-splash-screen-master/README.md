# flutter_animated_splash_screen

An animated splash screen that mimics a falling raindrop that removes the virtual surface covering the first screen of our app.

![The splash screen animation in action](https://www.flutterclutter.dev/wp-content/uploads/2020/07/flutter-splash-animation-rain-drop-red.gif)

# Article

Find the respective tutorial about how everything was created and how it's to be used on https://www.flutterclutter.dev/flutter/tutorials/beautiful-animated-splash-screen/2020/1108/ 